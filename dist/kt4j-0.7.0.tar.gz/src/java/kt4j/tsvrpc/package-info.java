/**
 * Kyoto Tycoon's TSV-RPC protocol support.
 */
package kt4j.tsvrpc;