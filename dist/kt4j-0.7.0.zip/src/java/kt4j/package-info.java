/**
 * The base KT4J API.
 */
package kt4j;