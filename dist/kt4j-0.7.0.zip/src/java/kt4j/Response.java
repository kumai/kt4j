package kt4j;

/**
 * A response from the Kyoto Tycoon.
 * 
 * @author kumai
 */
public interface Response {
    boolean isSucceeded();
}
