/**
 * Kyoto Tycoon's Binary protocol support.
 */
package kt4j.binary;